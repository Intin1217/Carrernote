import styled from 'styled-components';

export const LogoImg = styled.img`

  justify-content: center;

  margin: 40px 0;
`;
