export interface PostProps{
  title: string;
  content: string;
  category: string;
  date: string;
  writer: string;
  id: string;
}